import React from 'react'
import { CarouselContainer } from './CaroContnr';
import CardCarousel from './ReviewMain';

function Review() {
  return (
    <div>
         <CarouselContainer>
    

      <CardCarousel />
    </CarouselContainer>
        </div>
  )
}

export default Review