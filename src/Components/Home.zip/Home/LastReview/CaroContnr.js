import styled from "styled-components";

export const CarouselContainer = styled.div`
  max-height: 1000px;
  padding-left: 200px;
`;
