import React from 'react'
import CardCarousel from './Caroo'
import { CarouselContainer } from './CaroStyle'
import "./carousell"
function Finalcarousel2() {
  return (
    <div>
        <CarouselContainer>
            <CardCarousel/>
        </CarouselContainer>
    </div>
  )
}

export default Finalcarousel2