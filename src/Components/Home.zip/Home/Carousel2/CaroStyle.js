import styled from "styled-components";

export const CarouselContainer = styled.div`
  padding-top: 70px;
  padding:70px 0px 0px 70px;
  background-color:#f5f7fa;
`;
